package com.talagasoft.gojek.model;

/**
 * Created by compaq on 03/05/2016.
 */
public class Utils {
}
