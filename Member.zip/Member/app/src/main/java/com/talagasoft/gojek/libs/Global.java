package com.talagasoft.gojek.libs;

/**
 * Created by compaq on 01/22/2017.
 */

public class Global {
}
